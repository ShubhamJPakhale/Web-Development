import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {
  //http://localhost:3000

  private registerurl="/api/register";
  private loginurl="/api/login";

  constructor(private http:HttpClient,private router:Router) { }

  registerUser1(user:any){
    return this.http.post<any>(this.registerurl,user);
  }

  loginUser(user:any)
  {
    return this.http.post(this.loginurl,user);
  }

  loggedIn()
  {
    return !! localStorage.getItem('token');
  }

  getToken()
  {
    return localStorage.getItem('token');
  }

  logoutUser()
  {
    localStorage.removeItem('token');
    this.router.navigate(['/events'])
  }
}
