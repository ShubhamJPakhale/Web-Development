import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable,Injector } from '@angular/core';
import { AuthserviceService } from './authservice.service';

@Injectable({
  providedIn: 'root'
})
export class TokeninterceptorService implements HttpInterceptor{

  constructor(private injector:Injector) { }

  intercept(req:any, next: any) 
  { 
      let authservice = this.injector.get(AuthserviceService);
      let tokenizedReq = req.clone(
        {
          headers: req.headers.set('Authorization', 'bearer ' + authservice.getToken())
        }
      )
      // let tokenizedreq = req.clone({
      //   setHeaders :{
      //     Authorization :  `Bearer ${authservice.getToken()} `
      //   }
      // })

      return next.handle(tokenizedReq);
  }

  // intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
      
  // }

}
