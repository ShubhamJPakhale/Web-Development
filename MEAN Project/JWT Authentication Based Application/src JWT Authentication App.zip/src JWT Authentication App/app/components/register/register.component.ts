import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/authservice.service';
import {observable} from 'rxjs'
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl:'./register.component.html',
  styles: [
  ]
})
export class RegisterComponent implements OnInit {

  constructor(private auth:AuthserviceService,private router:Router) { }

  ngOnInit(): void {
  }

  registereduserdata= {
    email:"",
    password:""
  }

  registerUser()
  {
    this.auth.registerUser1(this.registereduserdata)
    .subscribe( 
      data => {
        console.log(data)
        localStorage.setItem('token',data.token)
        this.router.navigate(['/special']),

        (err:any)=> console.log(err);
      
      })
  }
}
