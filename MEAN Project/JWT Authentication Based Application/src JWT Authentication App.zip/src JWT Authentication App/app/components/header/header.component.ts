import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/authservice.service';

@Component({
  selector: 'app-header',
  template: `
<!-- <nav class="navbar navbar-expand-lg navbar-light bg-light" style="width: 100%;">
  <a class="navbar-brand h1 px-3" routerLink="/events">Authentication Portal</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto ">
      <li class="nav-item">
        <a class="nav-link text-dark" routerLink="/events" routerLinkActive="active">Events</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-dark" routerLink="/special" routerLinkActive="active">Special</a>
      </li>
    </ul>
    <ul class="navbar-nav">
      <a class="nav-link text-dark" routerLink="/login" routerLinkActive="active">Login</a>
      <a class="nav-link text-dark" routerLink="/register" routerLinkActive="active">register</a>
    </ul>
  </div>
</nav> -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" routerLink="/events">Authentication Portal</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" routerLink="/events" routerLinkActive="active">Event</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" routerLink="/special" routerLinkActive="active">Special_Event</a>
      </li>
    </ul>
    <ul class="navbar-nav">
        <a class="nav-link" *ngIf="!_authService.loggedIn()" routerLink="/login" routerLinkActive="active">Login</a>
        <a class="nav-link" *ngIf="!_authService.loggedIn()" routerLink="/register" routerLinkActive="active">Register</a>
        <a class="nav-link" style="cursor:pointer" *ngIf="_authService.loggedIn()" (click)="_authService.logoutUser()">Logout</a>        
    </ul>
  </div>
</nav>    
  `,
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(public _authService : AuthserviceService) { }

  ngOnInit(): void {
  }

}
