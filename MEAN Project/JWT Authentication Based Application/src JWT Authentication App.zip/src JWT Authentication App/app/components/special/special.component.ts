import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventserviceService } from 'src/app/eventservice.service';

@Component({
  selector: 'app-special',
  templateUrl:'./special.component.html',
  styles: [
  ]
})
export class SpecialComponent implements OnInit {

  specialevent:any=[];

  constructor(private eventservice :EventserviceService,private router:Router) { }

  ngOnInit(): void {
    this.eventservice.getSpecialEvent().subscribe(
      data => {
        this.specialevent = data, 

        (err:any) =>{ 
          if(err instanceof HttpErrorResponse)
          {
            if(err.status ===401)
            {
              this.router.navigate(['/login'])
            }
          }}
      
      })
  }

}
