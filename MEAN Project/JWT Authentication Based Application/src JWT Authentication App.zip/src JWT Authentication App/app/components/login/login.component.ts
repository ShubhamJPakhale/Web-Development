import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/authservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: [
  ]
})
export class LoginComponent implements OnInit {

  constructor(private auth:AuthserviceService,private router:Router) { }

  ngOnInit(): void {
  }

  Loginuserdata={
    email : "",
    password:""
  }

  Loginuser()
  {
    this.auth.loginUser(this.Loginuserdata)
    .subscribe( 
      (res:any) => {
        console.log(res);
        localStorage.setItem('token',res.token)
        this.router.navigate(['/special']),

        (err:any)=> console.log(err);
      
      });
  }
}
