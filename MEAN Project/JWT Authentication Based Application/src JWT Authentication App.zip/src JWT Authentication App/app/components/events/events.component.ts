import { Component, OnInit } from '@angular/core';
import { EventserviceService } from 'src/app/eventservice.service';

@Component({
  selector: 'app-events',
  templateUrl:'./events.component.html',
  styles: [
  ]
})
export class EventsComponent implements OnInit {

  events:any=[];

  constructor(private eventservice :EventserviceService) { }

  ngOnInit(): void {
    this.eventservice.getEvents().subscribe(data => {this.events = data, (err:any) => console.log(err)})
  }

}
