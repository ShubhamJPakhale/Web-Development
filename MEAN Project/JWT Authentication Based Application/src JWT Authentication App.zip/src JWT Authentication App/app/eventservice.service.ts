import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EventserviceService {

  private eventurl="/api/events";
  private specialurl="/api/special";

  constructor(private http:HttpClient) { }

  getEvents()
  {
    return this.http.get<any>(this.eventurl);
  }

  getSpecialEvent()
  {
    return this.http.get<any>(this.specialurl)
  }
}
