express=require('express');
var  bodyparser=require('body-parser');
api=require('./routes/api');
mongoose=require('mongoose');
cors = require('cors')

PORT =3000;

const app=express();
app.use('/api',api);
app.use(cors())

//app.use(bodyparser.urlencoded({extended: true}));

app.use(bodyparser.json());

app.listen(PORT,function(){
    console.log("server is running on port 3000");
})

app.get('/',(req,res)=>{
    res.send("Hello from server");
})

Database='mongodb+srv://shubham:shubham@users.kvi9vcp.mongodb.net/?retryWrites=true&w=majority'

mongoose.connect(Database).then(()=>
{
    console.log("Connection established Successfully");
}).catch((error)=>
{
    console.log("Error while establishing connection"+error);
})
