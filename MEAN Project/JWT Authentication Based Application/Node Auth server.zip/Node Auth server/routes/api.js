const express=require('express');
jwt = require('jsonwebtoken')
const User = require('../models/user');
//const router=express.Router();
var bodyparser=require('body-parser');

const app=express();

//app.use(bodyparser.urlencoded({extended: true}));

app.use(bodyparser.json());

function verifyToken(req, res, next) 
{
  if(!req.headers.authorization) 
  {
    return res.status(401).send('Unauthorized request')
  }
  let token = req.headers.authorization.split(' ')[1]
  if(token === 'null') 
  {
    return res.status(401).send('Unauthorized request')    
  }
  let payload = jwt.verify(token, 'secretKey')
  if(!payload) 
  {
    return res.status(401).send('Unauthorized request')    
  }
  req.userId = payload.subject
  next()
}

app.get('/',async (req,res)=>{
    //res.send("Data is send !!")
    const users=await User.find({});
    try {
        res.send(users);
    } catch (error) {
        res.status(500).send(error);
    }
});

app.post('/register',async (req,res)=>{
    let userdata=req.body;
    let user=new User(userdata);
    await user.save((err,registereduser)=>{
        if(err)
        {
            res.status(500).send(err);
        }
        else
        { 
            let payload={subject : registereduser._id};
            let token = jwt.sign(payload,"secretKey");
            res.status(200).send({token});
        }
    })
});

app.post('/login',async (req,res)=>{
    let userdata= new User(req.body);

    User.findOne({email:userdata.email},(err,user)=>
    {
        if(err)
        {
            res.status(500).send(err);
        }
        else{
            if(!user){
                res.status(401).send('Invalid Email');
            }else
            {
                if(user.password !==userdata.password)
                {
                    res.status(401).send('Invalid password');
                }else{
                    let payload={subject :user._id};
                    let token=jwt.sign(payload,"secretKey");
                    res.status(200).send({token});
                }
            }
        }
    })
});

app.get('/events',async (req,res)=>{
    let events=[
        {
            "_id":"1",
            "language":"Javascript",
            "framework":"vanilla js"
        },
        {
            "_id":"2",
            "language":"Typescript",
            "framework":"Superset of js"
        },
        {
            "_id":"3",
            "language":"Node.js",
            "framework":"Runtime environment of js"
        },
        {
            "_id":"4",
            "language":"Express",
            "framework":"Server for js"
        },
        {
            "_id":"5",
            "language":"MongoDb",
            "framework":"NoSQL Database"
        }
    ]

    await res.json(events);
});

app.get('/special',verifyToken,async (req,res)=>{
    let events=[
        {
            "_id":"1",
            "language":"Javascript",
            "framework":"vanilla js"
        },
        {
            "_id":"2",
            "language":"Typescript",
            "framework":"Superset of js"
        },
        {
            "_id":"3",
            "language":"Node.js",
            "framework":"Runtime environment of js"
        },
        {
            "_id":"4",
            "language":"Express",
            "framework":"Server for js"
        },
        {
            "_id":"5",
            "language":"MongoDb",
            "framework":"NoSQL Database"
        }
    ]

    await res.json(events);
})

module.exports = app;