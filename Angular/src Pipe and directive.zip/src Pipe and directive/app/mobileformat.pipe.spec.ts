import { MobileformatPipe } from './mobileformat.pipe';

describe('MobileformatPipe', () => {
  it('create an instance', () => {
    const pipe = new MobileformatPipe();
    expect(pipe).toBeTruthy();
  });
});
