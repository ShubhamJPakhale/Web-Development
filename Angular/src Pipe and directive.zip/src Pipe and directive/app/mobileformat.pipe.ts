import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mobileformat'
})
export class MobileformatPipe implements PipeTransform {

  // transform(value: unknown, ...args: unknown[]): unknown {
  //   return null;
  // }

  transform(rawNum:string):any
  {
   
    const start = rawNum.slice(0,3);
    const middle = rawNum.slice(3,6);
    const last = rawNum.slice(6,10);
    
    return `${start}-${middle}-${last}`;
  }
}
