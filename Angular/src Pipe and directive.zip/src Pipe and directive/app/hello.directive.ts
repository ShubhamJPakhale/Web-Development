import { Directive } from '@angular/core';
import { ElementRef,HostListener } from '@angular/core';


@Directive({
  selector: '[appHello]'
})
export class HelloDirective {

  constructor(private eobj:ElementRef) 
  { }


  //Logic
  @HostListener('mouseenter')onmouseenter()
  {
    this.eobj.nativeElement.style.background="green";
  }

  @HostListener('mouseleave')onmouseleave()
  {
    this.eobj.nativeElement.style.background="LightGray";
  }

}
