import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'demo'
})
export class DemoPipe implements PipeTransform {
  //<h1>{{"Jai Ganesh" | demo:"Angular":"Python":"LB"}}</h1>

  transform(value: unknown, ...args: unknown[]): unknown 
  {
    var str:string='';

    if(args[0] == "Angular")
    {
      str='You have learnt Angular on your own man!!';
    }

    return str;
  }

  
}
