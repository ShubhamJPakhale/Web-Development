import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SampleAngularApp';
  
  public name="Jai shree MAHAKAAL"
  public batches={"name":"Angular","fee":15000}

  public today=new Date();

  public no=1.239;

  public mob:any="9975856089";

  public fees=15000;
}
