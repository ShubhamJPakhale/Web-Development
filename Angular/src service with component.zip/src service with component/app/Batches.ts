export interface IBatches
{
    Name:string,
    Duration:number,
    Fees:number
}

//different file for service creatation using server http 