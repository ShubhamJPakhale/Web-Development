import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  template:`
  <div class="aboutdiv" style="padding-left:10px;"> 
    <h1>This is Aboutus Component!!!</h1>
  </div>
`,
  styles: [
  ]
})
export class AboutusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
