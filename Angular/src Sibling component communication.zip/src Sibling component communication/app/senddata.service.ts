import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SenddataService 
{
  // This Service demostrate the sibling communication in angular using service in that we are using subject library of rxjs to get input output data of our component

  myMethod$: Observable<any>;
  //myMethodSubject = new Subject<any>(); // this library for taking static value from component in angular 
  myMethodSubject=new BehaviorSubject<any>({}); // this library for taking realtime typed value from input fields in angular 

  constructor() {
      this.myMethod$ = this.myMethodSubject.asObservable();//this method puts mymethod subject input in to myMethod$ variable for initial
  }

  myMethod(data:any) {
    
     //console.log(data); // I have data! Let's return it so subscribers can use it!
      // // we can do stuff with data if we want
      this.myMethodSubject.next(data);// this method take input of sender com
     
  }
}
