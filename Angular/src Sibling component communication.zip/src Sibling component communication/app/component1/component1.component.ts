import { Component, OnInit } from '@angular/core';
import { SenddataService } from '../senddata.service';

@Component({
  selector: 'app-component1',
  template: `
  <h1>Inside First component </h1>
  Enter Language Name : <input #Nameoflanguage (change)="Submit(Nameoflanguage.value)">
  <button type="button" >Submit</button>
  `
})

export class Component1Component implements OnInit {
  //public data:any="Shubham Pakhale";

  public data:any;

  public Submit(value:any)
  {
    this._obj.myMethod(value);
  }
  constructor(private _obj: SenddataService) {}
  ngOnInit(): void 
  {
    //this._obj.myMethod(this.data);
  }

}
