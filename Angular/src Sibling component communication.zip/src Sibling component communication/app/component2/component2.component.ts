import { Component, OnInit } from '@angular/core';
import { SenddataService } from '../senddata.service';

@Component({
  selector: 'app-component2',
  template: `
  <h1 *ngIf="data "> Data from component 1 is {{data}}</h1>
  `
})
export class Component2Component implements OnInit {

  ngOnInit(): void {
  }

  public data:any;

  //Dependency injection 
  constructor(private _obj:SenddataService) //object of senddataservice variable in angular  
  { 
    this._obj.myMethod$.subscribe(data =>this.data=data);// recive data from service myMethod$ observable in to data variable  
  }

}
