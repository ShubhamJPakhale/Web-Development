import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactComponent } from './contact/contact.component';
import { DashboardModule } from './dashboard.module';

const routes: Routes = [
  {path:"",component:AboutusComponent},
  {path:"contact",component:ContactComponent,pathMatch:'full'},
  {path:"AboutUs",component:AboutusComponent,pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
