import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './Component/home/home.component';
import { LoginComponent } from './Component/login/login.component';
import { NavigationComponent } from './Component/navigation/navigation.component';
import { SignupComponent } from './Component/signup/signup.component';
import { DashboardModule } from './dashboard/dashboard.module';

const routes: Routes = [
  {path:"dashboard",loadChildren :()=>import('./dashboard/dashboard.module').then((m)=>m.DashboardModule)},
  {path:"login",component:LoginComponent,pathMatch:'full'},
  {path:"signup",component:SignupComponent,pathMatch:'full'},
  {path:"",component:HomeComponent,pathMatch:'full'},
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
