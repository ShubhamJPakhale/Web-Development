export class User {
    email!: String;
    password!: String;
  }