import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  hide = true;
    
  constructor(private fbuilder:FormBuilder) { }

  ngOnInit(): void {
  }

  LoginForm:FormGroup = this.fbuilder.group({
    email:['',[Validators.required,Validators.email]],
    password:['',[Validators.required,Validators.maxLength(20),Validators.minLength(2)]]
  })

  submit()
  {

  }

  setvalue()
  {
    this.LoginForm.setValue({
      email:"Test",
      password:"Test"
    })
  }

  Reset()
  {
    this.LoginForm.reset()
  }

  public myError = (controlName: string, errorName: string) =>{
    return this.LoginForm.controls[controlName].hasError(errorName);
    }
}
