import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @Input() Giftfromparent :any;

  //child to parent
  

  @Output()
  public myevent= new EventEmitter()
  public gifttoparent="This is gift from child to parent"

  childtoparent()
  {
    this.myevent.emit(this.gifttoparent);
  }
}
