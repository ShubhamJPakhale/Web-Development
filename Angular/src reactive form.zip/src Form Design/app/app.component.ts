import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SampleAngularApp';

  @Input() public model:any;

  public FirstName:any;

  public update(value:any)
  {
    this.FirstName=value;
  }
}
