import { Component, OnInit, Output ,EventEmitter} from '@angular/core';

@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @Output() public myevent=new EventEmitter();
  public FirstName:any;

  public senddata(value:any)
  {
    this.myevent.emit(this.FirstName);
  }
}
