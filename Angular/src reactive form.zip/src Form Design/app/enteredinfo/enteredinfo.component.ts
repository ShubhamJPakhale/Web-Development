import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-enteredinfo',
  templateUrl: './enteredinfo.component.html',
  styleUrls: ['./enteredinfo.component.css']
})
export class EnteredinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @Input() public MyData:any;
}
