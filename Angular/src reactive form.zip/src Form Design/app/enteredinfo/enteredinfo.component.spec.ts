import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnteredinfoComponent } from './enteredinfo.component';

describe('EnteredinfoComponent', () => {
  let component: EnteredinfoComponent;
  let fixture: ComponentFixture<EnteredinfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EnteredinfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnteredinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
