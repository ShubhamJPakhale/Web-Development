import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router'; 

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {

  public model:any;

  public name:any="Shubham Pakhale";

  constructor(private router: Router, ) {}  

  @Input() MyData:any;

  public onSubmit()
  {  
      this.router.navigate(['/SubmitBug'],this.MyData); // this will navigate to another component in angular  
  }  
}
