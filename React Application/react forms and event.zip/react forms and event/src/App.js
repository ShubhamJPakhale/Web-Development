import './App.css';
//import Forms from './Components/Forms';
import 'bootstrap/dist/css/bootstrap.css';
import Form2 from './Components/form2';
import Reactevent from './Components/Reactevent';
import ReactForm1 from './Components/ReactForm1';
import MultipleField from './Components/MultipleField';

function App() {
  return (
    <div className='Maindiv'>
      {/* <div className='Container'>
        <Forms></Forms>
      </div> */}
      {/* <Reactevent/> */}
      {/* <ReactForm1/> */}
      <MultipleField/>
    </div>
  );
}

export default App;
