import React, { useState } from 'react';
import './ReactForm1.css';

const initialValues = {
    company: "",
    position: "",
    experience:""
  };

function MultipleField() {

    const [values, setValues] = useState(initialValues);

    const handleInputChange = (e) => {
        //const name = e.target.name 
        //const value = e.target.value 
        const { name, value } = e.target;
    
        setValues({
          ...values,
          [name]: value,
        });
      };

    const handleSubmit = (event) => {
        event.preventDefault();
        alert(`The user entered details are as\nCompany : ${values.company} \nPosition : ${values.position} \nExperience : ${values.experience}`);
        event.target.reset();
    }
    
  return (
    <div className='main'>
    <div className='sub-main'>
        <form onSubmit={handleSubmit}>
        <div>
            <h3>React Form</h3>
        <div className='lbluser'>
            <label>Company </label><br/>
            <input  name='company' onChange={handleInputChange} type='text' value={values.company}></input>
        </div>
        <div className='lblpass'>
            <label>Position </label><br/>
            <input  name='position' onChange={handleInputChange} type='text' value={values.position}></input>
        </div>
        <div className='lblpass'>
            <label>Experience </label><br/>
            <input  name='experience' onChange={handleInputChange} type='text' value={values.experience}></input>
        </div>
        <div className='submit'>
            <button type='submit'  class="btn btn-primary mt-30">Submit</button>
        </div>
        </div>
        </form>
    </div>
    </div>
  )
}

export default MultipleField