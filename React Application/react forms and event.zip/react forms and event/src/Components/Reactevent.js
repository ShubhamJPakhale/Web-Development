import React from "react";
import { useState } from "react";
import './Reactevent.css';

function Reactevent()
{
    //events available in react as below :-
    var arrevent=["onClick","onMouseEnter",'onChange','onMouseLeave','onKeyUp','onKeyDown'];
    const list = arrevent.map((data) => <li>{data}</li>)
    
    //setting the property for taking user input value in react here we are using useState hook of react 
    const[name,setName]=useState("");
    const[email,setEmail]=useState("");

    const popup1 = (a,b) =>
    {
        alert(`Hello, ${a} !! \nThis is ${b.type} Event`);
    }
    const popup2 = () =>
    {
        alert(`Hey, You entered mouse in to Email field`);
    }

    const popup3 = (name) =>
    {
        alert(`Hey, You entered name in to name field is ${name}`);
    }

    return(
        <div className="eventstyle">
            <h1>Demonstration of React Events</h1>
            <h6>In react, we can see various events are available for html elements as follows like </h6>
            <ul>
                {list}
            </ul>
            <hr/>
            <h2>Some Example of events in react how we can use as below :-</h2>
            <button type='button' onClick={(event)=>popup1('Shubham',event)}>Click Event</button>
            <br/>
            <label>Enter Your Name :-
            <input type='text' value={name} onChange={(e)=> setName(e.target.value)} /> 
            </label>
            <label>Entered name is : {name}</label><br/>
            <label>Enter Your Email :-
            <input type='text' value={email} onMouseEnter={popup2}/> 
            </label><br/>
        </div>
    );
}

export default Reactevent;