import React, { useState } from 'react';
import './ReactForm1.css';

function ReactForm1() {

    const [name,setName]=useState("");
    const [password,setPassword]=useState("");
    const [terms,setTerms]=useState(false);

    const handleSubmit = (event) => {
        event.preventDefault();
        alert(`The user entered details are as\nName: ${name}\nPassword :${password}\ntermas : ${terms} `);
        event.target.reset();
    }

    const handleChange = event => {
        if (event.target.checked) {
          alert('✅ Checkbox is checked');
        } else {
          alert('⛔️ Checkbox is NOT checked');
        }
        setTerms(current => !current);
    };

  return (
    <div className='main'>
    <div className='sub-main'>
        <form onSubmit={handleSubmit}>
        <div>
            <h3>Login Page</h3>
        <div className='lbluser'>
            <label>Username </label><br/>
            <input  name='name' onChange={(e)=>setName(e.target.value)} type='text' className='username'></input>
        </div>
        <div className='lblpass'>
            <label>Password </label><br/>
            <input  name='password' onChange={(e)=>setPassword(e.target.value)} type='password' className='password'></input>
        </div>
        <div className='chkrules'>
        <input class="form-check-input" name='terms'value={terms} onChange={handleChange} type="checkbox" id="flexCheckDefault"/>
        <label class="form-check-label" for="flexCheckDefault">
            Please agree to terms and condition
        </label>
        </div>
        <div className='submit'>
            <button type='submit' disabled={!name || !password || !terms } class="btn btn-primary mt-30">Submit</button>
        </div>
        <div className='new'>
            <p>First time user <a href='/'>Click here to Signinthe Application</a></p>
        </div>
        </div>
        </form>
    </div>
    </div>
  )
}

export default ReactForm1