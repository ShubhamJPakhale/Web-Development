import React from 'react'

function Service ()  {
    const arr=['React','Redux','Angular','JavaScript','Typescript','Node.js','Express.js','MongoDB'];
    const mylist=arr.map((item)=><li>{item}</li>)
    return (
        <div>
            <h1>This is Service Page</h1>
            <h3>Array map method for iteration over Array in react :- </h3>
            <ul>
                {mylist}
            </ul>
        </div>
    )
}

export default Service;