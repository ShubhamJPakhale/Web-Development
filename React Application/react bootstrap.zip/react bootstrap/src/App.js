import './App.css';

function App() {
  var a=10;
  var value = a<=50?" Less than 50":" Greater than 51"
  return (
    <div className="App">
      <h1>This is Homepage</h1>
      <h3>{a} is {value}</h3>
    </div>
  );
}

export default App;
