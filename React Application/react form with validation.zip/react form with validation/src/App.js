import './App.css';
import Formwithvalidation from './Components/Formwithvalidation';
import 'bootstrap/dist/css/bootstrap.css';

function App() {
  return (
    <div className="App">
      <h1>React Form with validation errors</h1>
      <Formwithvalidation/>
    </div>
  );
}

export default App;
