import React, { useEffect, useState } from 'react'
import './divstyle.css';

function Formwithvalidation() {
    const initialvalues={name:"",emailID:"",mobile_Number:"",password:""};
    const [formvalues,setFormvalues]=useState(initialvalues);
    const [formErrors,setFormerrors]=useState('');
    const [issubmit,setIsSubmit]=useState(false);

    const handleChange = (e)=>{
        const {name,value}=e.target;
        setFormvalues({...formvalues,[name]:value});
       
    }

    const handlesubmit =(e)=>{
        e.preventDefault();
        setFormerrors(validate(formvalues));
        setIsSubmit(true);
    };

    useEffect(()=>{
        console.log(formErrors);
        if(Object.keys(formErrors).length ===0 && issubmit){
            console.log(formvalues);
        }
    },[formErrors])

    const validate = (values) =>{
        const errors={};

        const emailregex= /^[a-zA-Z0-9]+@(?:[a-zA-Z0-9]+\.)+[A-Za-z]+$/;
        const mobileregex = /^[0-9]{10}$/;

        if(!values.name)
        {
            errors.name="Name is required field";
        }

        if(!values.emailID)
        {
            errors.emailID="Email id is required field";
        }
        else if(!emailregex.test(values.emailID))
        {
            errors.emailID="Please enter correct email id"
        }

        if(!mobileregex.test(values.mobile_Number))
        {
            errors.mobile_Number="Mobile number must be numberic and 10 digits only"
        }
        else if(values.mobile_Number.length < 10)
        {
            errors.mobile_Number="Mobile number should be atleast 10 digit";
        }
        

        if(!values.password)
        {
            errors.password="Password is required field";
        }
        else if(values.password.length < 4)
        {
            errors.password = "Password must be minimum 4 characters"
        }

        return errors;
    }


  return (
    <div className='maindiv'>
        <div className='subdiv'>
        <form onSubmit={handlesubmit}>
        {Object.keys(formErrors).length ===0 && issubmit ? (<div class="btn btn-success">Data Saved Successfully</div>):(<pre>{JSON.stringify(formvalues,undefined,2)}</pre>)}
        
        <div>
            <label>Name :</label><br/>
            <input type='text' value={formvalues.name} name="name" onChange={handleChange}></input>
            <p className='errorstyle'>{formErrors.name}</p>
        </div>
        <div>
            <label>EmailID :</label><br/>
            <input type='text' value={formvalues.emailID} name="emailID" onChange={handleChange}></input>
            <p className='errorstyle'>{formErrors.emailID}</p>
        </div>
        <div>
            <label>Mobile Number :</label><br/>
            <input type='text' value={formvalues.mobile_Number} name="mobile_Number" 
            onChange={handleChange} maxLength={10} ></input>
            <p className='errorstyle'>{formErrors.mobile_Number}</p>
        </div>
        <div>
            <label>Password :</label><br/>
            <input type='password' value={formvalues.password}  name="password" 
            onChange={handleChange} ></input>
            <p className='errorstyle'>{formErrors.password}</p>
        </div>
        <div>
           <button type='submit' class="btn btn-primary" disabled={!formvalues.emailID || !formvalues.mobile_Number || !formvalues.password}>Submit</button>
        </div>
        </form>
    </div>
    </div>
  )
}

export default Formwithvalidation