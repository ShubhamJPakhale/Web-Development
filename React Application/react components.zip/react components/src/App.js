import './App.css';
import Sum from './Components/Sum';
import Multiply from './Components/Multiply';

function App() {
  return (
    <div className="App">
      <Sum name="Shubham Pakhale"></Sum>
      <Multiply></Multiply>
    </div>
  );
}

export default App;
