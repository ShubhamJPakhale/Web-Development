import React from "react";
import './Sum.css'

function Sum(props){
    return( 
        <div className="sumstyle">
            <h1>Hello, {props.name}</h1>
        </div>);
};

export default Sum;