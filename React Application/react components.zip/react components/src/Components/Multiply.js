import React,{Component} from "react";
import './Multiply.css'

class Multiply extends Component{
    render(){
        return (
            <div className="mulstyle">
                <h1>This is multiplication component</h1>
            </div>
        );
    }
}

export default Multiply;