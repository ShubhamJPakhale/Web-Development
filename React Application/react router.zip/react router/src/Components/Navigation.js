import Nav from 'react-bootstrap/Nav';
import Link from 'react-router-dom';

function Navigation() {
  return (
    <Nav fill variant="tabs" defaultActiveKey="/home">
      <Nav.Item>
        <Nav.Link href="/home">Home</Nav.Link>
      </Nav.Item>
      <Nav.Item>
        <Nav.Link  href="/AboutUs">AboutUs</Nav.Link>
      </Nav.Item>
    </Nav>
  );
}

// function Navigation()
// {
//   return (
//     <>
//       <nav className='nav'>
//         <Link to='/'>Site Title
//         </Link>
//       </nav>
//     </>
//   )
// }
export default Navigation;