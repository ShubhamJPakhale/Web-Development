import logo from '../Images/ecofriendly.png';
import './Header.css'
import React from 'react';

function Headertitle (){
    return(
        <div className='headerstyle'>
             <img src={logo} alt="Image is not loaded" className='imagestyle'/>
             <span>Ganpati Bappa Morya</span>
        </div>
    );

}

export default Headertitle;