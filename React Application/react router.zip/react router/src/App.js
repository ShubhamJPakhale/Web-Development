import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import Navigation from './Components/Navigation';
import Headertitle from './Components/Header';
import {Route,Routes} from 'react-router-dom';
import Home from './Components/Home';
import AboutUs from './Components/AboutUs';

function App() {
  return (
    <>
    <Headertitle></Headertitle>
    <div className="App">
      <Navigation></Navigation>
    </div>
    </>
  );
}

export default App;
