//if else loop 
var val1=10;
if(val1 <= 15)
{
    console.log("Number is less than 15");
}
else{
    console.log("Number is greater than 15");
}

//for loop 
for(var i=0;i<5;i++)
{
    console.log("i = "+i);
}

// for in loop 
arr=["apple","banana","mango","pineapple","orange","kivi"]
for(var m in arr)
{
    console.log("element in arr array at index "+m+" is "+arr[m]);
}

// for of loop 
brr=[10,20,30,40,50,60];
for( var item of brr)
{
    console.log("item in array is "+item);
}

//for of with destructuring array 
var data=['Angular', 'JavaScript', 'TypeScript'];
for (const [i, v] of data.entries()) {
    console.log(i, v)
  }

//while loop
var val= 5;
while(val <11)
{
    console.log("val is "+val);
    val++;
}

//do while loop 
var val2=5;
do
{
   console.log("do while loop execute minimum once in loop even condition is false");
}while(val<5)

