var c= new Promise((resolve,reject)=>{
    setTimeout(() => {
        let a=10;
        let b=5;
        resolve(ret=a*b)
    }, 2000);
})

c.then((ret)=>console.log("Multiplication of number is "+ret)).catch((err)=>console.log(err));

console.log("This is example of promise in javascript");