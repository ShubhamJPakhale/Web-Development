console.log(`Current Directory is ${__dirname}`);

console.log(`Current file name is ${__filename}`);
