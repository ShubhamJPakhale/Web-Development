const fs=require("fs");
const path = require("path");

const curpath=path.join(__dirname,"abc"); // this will return our abc file path 
console.log(curpath);

//fs writefilesync module will crete file in currect directory 
fs.writeFileSync("abc.txt","This is abc file created it using node fs mofule");

//this module is used to update the file
fs.appendFile("abc.txt"," We are appending the data to abc.txt file existing data with our new data",(err)=>
{
    if(!err)
    {
        console.log("File updated successfully !!");
    }
});

// this module is used to read data from file using node fs module
fs.readFile("abc.txt","utf8",(err,item)=>
{
    if(err)
    {
        console.log(err);
    }
    else{
        console.log("Data in file :- \n"+item);
    }
})

//fs unlinksync module will delete file from current directory if file is present else throw error
fs.unlinkSync("abc.txt");