/**
 * Middle ware is used to avoid the user from accessing webpage if he not fulfill the condition 
 *There are various kind of middleware in node.js as follows :- 
 1. Application level middleware
 2. route level middleware
 3. Error handling 
 4. Build in 
 5. Third party 
 */

const express=require('express');
const middle=require('./middleware1');

const app=express();
//const route=express.Router();
app.use(middle);

// application level middleware 
app.get('',middle,(req,res)=>{
    res.send("welcome to page");
})

app.listen(3100);