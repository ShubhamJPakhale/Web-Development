var module1=require("./module1");

var ret=module1(75);
console.log(ret);
