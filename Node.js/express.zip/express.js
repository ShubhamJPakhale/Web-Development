/* Express js is framework of node.js :-
    It is used for creating server for node.js. which establish client server connection in web server.
    npm install express --save -> command to install express in machine

*/

const express=require('express');
const port=3100;

const app=express();
app.use(express.json()); // this is used to stringify the json data from object to json and used to store in database

app.get("",(req,res)=>{
    res.send("Hello this is basic api of node.js using express server!!");
});

app.listen(port);
console.log(`server is running on port ${port}`);