var a=10;
console.log(typeof a); // number

console.log(typeof b);
var b="hello"; // undefined

console.log(typeof b);// string 

var ret=true;
console.log(typeof ret);// boolean

//date in js
var date=new Date();
console.log(date.getDate() +'/'+ (date.getMonth()+1) +'/'+  date.getFullYear());
console.log(typeof date);// object 

//Json data 
var demo=[{name:"Angular",owner:"Google"},{name:"React",owner:"Meta"},{name:"Java",owner:"Sun Microsystem"},];

console.log(typeof demo);// object 

//Array 
var arr=["A","B","C"];
console.log(typeof arr);

//tuple
var trr=[10,true,"Hello",null,undefined];
console.log(typeof trr);