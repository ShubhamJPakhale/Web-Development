const emoji = require('node-emoji');
const filterdata= (req,res,next)=>
{
    if(!req.query.type)
    {
        res.send("Please Write any of the type as query parameter in url of page")
    }
    else if(req.query.type)
    {
        res.send(`<h1 style="text-align:center;">opps, you are ${req.query.type}.. happy to serve you  ${req.query.type} menu...</h1>`);
        next();
    }
    // else if(req.query.type = "nonveg"){
    //     res.send("opps, you are Non-vegetarian.. happy to serve you non-veg menu..."+emoji.get("biryani"));
    // }
    else{
       next();
    }
}

module.exports=filterdata;