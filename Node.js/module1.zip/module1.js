function abc (a) {
    let ret;
    if(a<40)
    {
        ret="You are Failed";
        return ret;
    }
    else if(a<60)
    {
        ret="You are just Passed";
        return ret;
    }
    else if(a<=66)
    {
        ret="You are Passed";
        return ret;
    }
    else{
        ret = "You are Passed with Distinction";
        return ret;
    }
}

module.exports = abc;