const express=require('express');
//const bodyparser=require('body-Parser');
const port=3100;

const app=express();
app.use(express.json()); // this is used to stringify the json data from object to json and used to store in database

app.get("",(req,res)=>{
    if(req.query.name != undefined)
    {
        console.log("data send from browser "+ req.query.name);
    }
    
    res.send("Hello this is basic api of node.js using express server!!");
    
});

app.listen(port);
console.log(`server is running on port ${port}`);