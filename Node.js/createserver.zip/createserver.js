var http=require('http');

var server=http.createServer((req,res)=>{
    
    if (req.url == '/') { //check the URL of the current request
        
        // set response header
        res.writeHead(200, { 'Content-Type': 'text/html' }); 
        
        // set response content   
        res.write("<h1 style='text-align:center;'>This is http server using http package of Node.js</h1>"); 
        res.write('<html><body><p>This is home Page.</p></body></html>');
        res.end();
    
    }
    else if (req.url == "/student") {
        
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write("<h1 style='text-align:center;'>This is http server using http package of Node.js</h1>"); 
        res.write('<html><body><p>This is student Page.</p></body></html>');
        res.end();
    
    }
    else if (req.url == "/admin") {
        
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write("<h1 style='text-align:center;'>This is http server using http package of Node.js</h1>"); 
        res.write('<html><body><p>This is admin Page.</p></body></html>');
        res.end();
    
    }
    else
        res.end('Invalid Request!');

});

server.listen(3100);

console.log("Server is running at port 3100");